# Routed 3-profile post-route STA with symmetric electrical constraints
set liberty /foss/pdks/sky130A/libs.ref/sky130_fd_sc_hd/lib/sky130_fd_sc_hd__tt_025C_1v80.lib
set_units -time ns -capacitance pF -voltage V -power W
read_liberty $liberty
read_verilog /artifacts/routed.v
link_design familyrtl_ecc_ppa
create_clock -name virtual_clock -period 10.0
set_input_delay 0.0 -clock virtual_clock [all_inputs]
set_output_delay 0.0 -clock virtual_clock [all_outputs]
set_input_transition 0.05 [all_inputs]
set_load 0.005 [all_outputs]
set_max_delay 10.0 -from [all_inputs] -to [all_outputs]
read_spef /artifacts/routed.spef
report_checks -path_delay max -format full -fields {slew cap input_pin net fanout} -digits 6
report_wns
report_tns
check_setup -verbose
puts "FAMILYRTL_ROUTED_3P_STA_COMPLETE"
