# Routed 3-profile post-route activity power with symmetric electrical constraints
set liberty /foss/pdks/sky130A/libs.ref/sky130_fd_sc_hd/lib/sky130_fd_sc_hd__tt_025C_1v80.lib
set_units -time ns -capacitance pF -voltage V -power W
read_liberty $liberty
read_verilog /artifacts/routed.v
link_design familyrtl_ecc_ppa
create_clock -name measurement_window -period 10.0
set_input_delay 0.0 -clock measurement_window [all_inputs]
set_output_delay 0.0 -clock measurement_window [all_outputs]
set_input_transition 0.05 [all_inputs]
set_load 0.005 [all_outputs]
read_spef /artifacts/routed.spef
read_vcd -scope ecc_v3_tb/dut /artifacts/current_activity.vcd
report_activity_annotation -report_annotated > /artifacts/current_activity_annotation.log
report_power -digits 9 > /artifacts/current_power.log
if {[catch {source /artifacts/instance_power_diagnostic.tcl} diagnostic_error]} {
  set diagnostic_file [open /artifacts/current_instance_power_error.txt w]
  puts $diagnostic_file $diagnostic_error
  close $diagnostic_file
}
puts "FAMILYRTL_ROUTED_3P_POWER_COMPLETE"
