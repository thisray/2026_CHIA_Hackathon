#!/usr/bin/env bash
set -uo pipefail

echo "=== Stage 1: Post-route STA ==="
sta -exit /artifacts/routed_3p_sta.tcl > /artifacts/postroute_sta.log 2>&1
sta_status=$?
echo "sta_status=${sta_status}"

echo "=== Stage 2: Gate-level simulation compilation ==="
iverilog -g2012 -DFUNCTIONAL \
  -DECC_V3_DATA_WIDTH=64 \
  -DECC_V3_PARITY_WIDTH=7 \
  -DECC_V3_CODEWORD_WIDTH=71 \
  -o /artifacts/simv \
  /foss/pdks/sky130A/libs.ref/sky130_fd_sc_hd/verilog/primitives.v \
  /foss/pdks/sky130A/libs.ref/sky130_fd_sc_hd/verilog/sky130_fd_sc_hd.v \
  /artifacts/routed.v /workspace/eda/ecc_v3/ecc_v3_tb.sv \
  > /artifacts/iverilog.log 2>&1
iverilog_status=$?
echo "iverilog_status=${iverilog_status}"

sim_status=0
power_status=0

for p in stress_encoded valid_uniform valid_low_toggle; do
  if [[ ${sta_status} -eq 0 && ${iverilog_status} -eq 0 ]]; then
    echo "=== Profile $p: Simulation ==="
    cd /artifacts && vvp /artifacts/simv \
      +workload=/artifacts/workload_${p}.hex \
      +vcd=/artifacts/activity_${p}.vcd \
      +profile=${p} +expected=1024 +interval_ps=10000 \
      > /artifacts/sim_${p}.log 2>&1
    p_sim_exit=$?
    echo "${p_sim_exit}" > /artifacts/sim_${p}.exit
    if [[ ${p_sim_exit} -ne 0 ]]; then
      sim_status=1
    fi

    if [[ -f /artifacts/activity_${p}.vcd ]]; then
      sha256sum /artifacts/activity_${p}.vcd | awk '{print $1}' > /artifacts/vcd_${p}.sha256
      cp /artifacts/activity_${p}.vcd /artifacts/current_activity.vcd
      sta -exit /artifacts/routed_3p_power.tcl > /artifacts/opensta_${p}.log 2>&1
      p_power_exit=$?
      echo "${p_power_exit}" > /artifacts/power_${p}.exit
      if [[ ${p_power_exit} -ne 0 ]]; then
        power_status=1
      fi
      mv /artifacts/current_power.log /artifacts/power_${p}.log 2>/dev/null
      mv /artifacts/current_activity_annotation.log /artifacts/annotation_${p}.log 2>/dev/null
      mv /artifacts/current_instance_power.json /artifacts/instance_power_${p}.json 2>/dev/null || true
      mv /artifacts/current_instance_pin_nets.tsv /artifacts/instance_pin_nets_${p}.tsv 2>/dev/null || true
      mv /artifacts/current_instance_power_error.txt /artifacts/instance_power_${p}.error.txt 2>/dev/null || true
      rm -f /artifacts/current_activity.vcd
      if [[ "False" == "True" ]]; then
        rm -f /artifacts/activity_${p}.vcd
      fi
    else
      sim_status=1
      power_status=1
    fi
  else
    sim_status=1
    power_status=1
  fi
done

cat > /artifacts/stage_status.json <<EOF
{
  "postroute_sta": ${sta_status},
  "iverilog_compile": ${iverilog_status},
  "simulation": ${sim_status},
  "power": ${power_status}
}
EOF

echo "FAMILYRTL_ECC_ROUTED_3P_MEASUREMENT_COMPLETE"
