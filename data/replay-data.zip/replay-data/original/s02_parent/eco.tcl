set_thread_count 2
set liberty /foss/pdks/sky130A/libs.ref/sky130_fd_sc_hd/lib/sky130_fd_sc_hd__tt_025C_1v80.lib
set_units -time ns -capacitance pF -voltage V -power W
read_db /artifacts/original_routed.odb
read_liberty $liberty
write_def /artifacts/original_placement.def
create_clock -name virtual_clock -period 10.0
set_input_delay 0.0 -clock virtual_clock [all_inputs]
set_output_delay 0.0 -clock virtual_clock [all_outputs]
set_input_transition 0.05 [all_inputs]
set_load 0.005 [all_outputs]
set_max_delay 10.0 -from [all_inputs] -to [all_outputs]
read_spef /artifacts/original_routed.spef
puts CHIA_POLARITY_ACTION_ORIGINAL_EXTRACTED_BEGIN
report_checks -path_delay max -format full -digits 6
report_design_area
puts CHIA_POLARITY_ACTION_ORIGINAL_EXTRACTED_END

set db [ord::get_db]
set block [ord::get_db_block]


set targets [list]
set handle [open /artifacts/targets.tsv r]
set target_data [read $handle]
close $handle
foreach line [split $target_data "
"] {
    if {[string trim $line] eq ""} { continue }
    set fields [split $line "	"]
    if {[llength $fields] != 5} { error "invalid target specification" }
    lassign $fields inst_name old_master_name new_master_name old_out_pin new_out_pin
    lappend targets $inst_name [list $old_master_name $new_master_name $old_out_pin $new_out_pin]
}
if {[llength $targets] == 0} { error "empty target specification" }

foreach {inst_name spec} $targets {
    lassign $spec old_master_name new_master_name old_out_pin new_out_pin
    set target_master [$db findMaster $new_master_name]
    if {$target_master eq "NULL"} { error "$new_master_name master not found" }
    set inst [$block findInst $inst_name]
    if {$inst eq "NULL"} { error "instance $inst_name missing" }
    set old_master [$inst getMaster]
    if {[$old_master getName] ne $old_master_name} {
        error "$inst_name expected master $old_master_name, got [$old_master getName]"
    }
    if {[$old_master getWidth] != [$target_master getWidth] || [$old_master getHeight] != [$target_master getHeight]} {
        error "dimension mismatch between old and new master for $inst_name"
    }
    set a_net [[$inst findITerm A] getNet]
    set b_net [[$inst findITerm B] getNet]
    set out_net [[$inst findITerm $old_out_pin] getNet]
    lassign [$inst getLocation] loc_x loc_y
    set orient [$inst getOrient]
    set pstatus [$inst getPlacementStatus]

    odb::dbInst_destroy $inst
    set new_inst [odb::dbInst_create $block $target_master $inst_name]
    $new_inst setOrient $orient
    $new_inst setLocation $loc_x $loc_y
    $new_inst setPlacementStatus $pstatus

    [$new_inst findITerm A] connect $a_net
    [$new_inst findITerm B] connect $b_net
    [$new_inst findITerm $new_out_pin] connect $out_net
}

write_verilog /artifacts/eco_pre_route.v
write_db /artifacts/eco_pre_route.odb
write_def /artifacts/eco_placement.def
puts CHIA_POLARITY_ACTION_COMPLETE
