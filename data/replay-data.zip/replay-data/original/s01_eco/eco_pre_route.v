module familyrtl_ecc_ppa (double_error_o,
    parity_error_o,
    single_error_o,
    data_i,
    data_o,
    syndrome_o);
 output double_error_o;
 output parity_error_o;
 output single_error_o;
 input [71:0] data_i;
 output [63:0] data_o;
 output [6:0] syndrome_o;

 wire _000_;
 wire _001_;
 wire _002_;
 wire _003_;
 wire _004_;
 wire _005_;
 wire _006_;
 wire _007_;
 wire _008_;
 wire _009_;
 wire _010_;
 wire _011_;
 wire _012_;
 wire _013_;
 wire _014_;
 wire _015_;
 wire _016_;
 wire _017_;
 wire _018_;
 wire _019_;
 wire _020_;
 wire _021_;
 wire _022_;
 wire _023_;
 wire _024_;
 wire _025_;
 wire _026_;
 wire _027_;
 wire _028_;
 wire _029_;
 wire _030_;
 wire _031_;
 wire _032_;
 wire _033_;
 wire _034_;
 wire _035_;
 wire _036_;
 wire _037_;
 wire _038_;
 wire _039_;
 wire _040_;
 wire _041_;
 wire _042_;
 wire _043_;
 wire _044_;
 wire _045_;
 wire _046_;
 wire _047_;
 wire _048_;
 wire _049_;
 wire _050_;
 wire _051_;
 wire _052_;
 wire _053_;
 wire _054_;
 wire _055_;
 wire _056_;
 wire _057_;
 wire _058_;
 wire _059_;
 wire _060_;
 wire _061_;
 wire _062_;
 wire _063_;
 wire _064_;
 wire _065_;
 wire _066_;
 wire _067_;
 wire _068_;
 wire _069_;
 wire _071_;
 wire _072_;
 wire _073_;
 wire _074_;
 wire _075_;
 wire _076_;
 wire _077_;
 wire _078_;
 wire _079_;
 wire _080_;
 wire _081_;
 wire _082_;
 wire _083_;
 wire _084_;
 wire _085_;
 wire _086_;
 wire _087_;
 wire _088_;
 wire _089_;
 wire _090_;
 wire _091_;
 wire _092_;
 wire _093_;
 wire _094_;
 wire _095_;
 wire _096_;
 wire _097_;
 wire _098_;
 wire _099_;
 wire _100_;
 wire _101_;
 wire _102_;
 wire _103_;
 wire _104_;
 wire _105_;
 wire _106_;
 wire _107_;
 wire _108_;
 wire _109_;
 wire _110_;
 wire _111_;
 wire _112_;
 wire _113_;
 wire _114_;
 wire _115_;
 wire _116_;
 wire _117_;
 wire _118_;
 wire _119_;
 wire _120_;
 wire _121_;
 wire _122_;
 wire _123_;
 wire _124_;
 wire _125_;
 wire _126_;
 wire _127_;
 wire _128_;
 wire _129_;
 wire _130_;
 wire _131_;
 wire _132_;
 wire _133_;
 wire _134_;
 wire _135_;
 wire _136_;
 wire _137_;
 wire _138_;
 wire _139_;
 wire _140_;
 wire _141_;
 wire _142_;
 wire _143_;
 wire _144_;
 wire _145_;
 wire _146_;
 wire _147_;
 wire _148_;
 wire _149_;
 wire _150_;
 wire _151_;
 wire _152_;
 wire _153_;
 wire _154_;
 wire _155_;
 wire _156_;
 wire _157_;
 wire _158_;
 wire _159_;
 wire _160_;
 wire _161_;
 wire _162_;
 wire _163_;
 wire _164_;
 wire _165_;
 wire _166_;
 wire _167_;
 wire _168_;
 wire _169_;
 wire _170_;
 wire _171_;
 wire _172_;
 wire _173_;
 wire _174_;
 wire _175_;
 wire _176_;
 wire _177_;
 wire _178_;
 wire _179_;
 wire _180_;
 wire _181_;
 wire _182_;
 wire _183_;
 wire _184_;
 wire _185_;
 wire _186_;
 wire _187_;
 wire _188_;
 wire _189_;
 wire _190_;
 wire _191_;
 wire _192_;
 wire _193_;
 wire _194_;
 wire _195_;
 wire _196_;
 wire _197_;
 wire _198_;
 wire _199_;
 wire _200_;
 wire _201_;
 wire _202_;
 wire _203_;
 wire _204_;
 wire _205_;
 wire _206_;
 wire _207_;
 wire _208_;
 wire _209_;
 wire _210_;
 wire _211_;
 wire _212_;
 wire _213_;

 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_0_Left_43 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_0_Right_0 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_10_Left_53 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_10_Right_10 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_11_Left_54 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_11_Right_11 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_12_Left_55 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_12_Right_12 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_13_Left_56 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_13_Right_13 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_14_Left_57 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_14_Right_14 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_15_Left_58 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_15_Right_15 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_16_Left_59 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_16_Right_16 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_17_Left_60 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_17_Right_17 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_18_Left_61 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_18_Right_18 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_19_Left_62 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_19_Right_19 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_1_Left_44 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_1_Right_1 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_20_Left_63 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_20_Right_20 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_21_Left_64 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_21_Right_21 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_22_Left_65 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_22_Right_22 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_23_Left_66 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_23_Right_23 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_24_Left_67 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_24_Right_24 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_25_Left_68 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_25_Right_25 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_26_Left_69 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_26_Right_26 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_27_Left_70 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_27_Right_27 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_28_Left_71 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_28_Right_28 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_29_Left_72 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_29_Right_29 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_2_Left_45 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_2_Right_2 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_30_Left_73 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_30_Right_30 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_31_Left_74 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_31_Right_31 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_32_Left_75 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_32_Right_32 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_33_Left_76 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_33_Right_33 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_34_Left_77 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_34_Right_34 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_35_Left_78 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_35_Right_35 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_36_Left_79 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_36_Right_36 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_37_Left_80 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_37_Right_37 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_38_Left_81 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_38_Right_38 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_39_Left_82 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_39_Right_39 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_3_Left_46 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_3_Right_3 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_40_Left_83 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_40_Right_40 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_41_Left_84 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_41_Right_41 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_42_Left_85 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_42_Right_42 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_4_Left_47 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_4_Right_4 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_5_Left_48 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_5_Right_5 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_6_Left_49 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_6_Right_6 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_7_Left_50 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_7_Right_7 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_8_Left_51 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_8_Right_8 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_9_Left_52 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_9_Right_9 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_0_86 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_0_87 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_0_88 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_0_89 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_0_90 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_0_91 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_0_92 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_0_93 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_10_130 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_10_131 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_10_132 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_10_133 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_11_134 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_11_135 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_11_136 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_11_137 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_12_138 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_12_139 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_12_140 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_12_141 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_13_142 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_13_143 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_13_144 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_13_145 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_14_146 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_14_147 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_14_148 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_14_149 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_15_150 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_15_151 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_15_152 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_15_153 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_16_154 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_16_155 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_16_156 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_16_157 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_17_158 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_17_159 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_17_160 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_17_161 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_18_162 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_18_163 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_18_164 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_18_165 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_19_166 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_19_167 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_19_168 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_19_169 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_1_94 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_1_95 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_1_96 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_1_97 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_20_170 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_20_171 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_20_172 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_20_173 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_21_174 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_21_175 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_21_176 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_21_177 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_22_178 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_22_179 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_22_180 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_22_181 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_23_182 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_23_183 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_23_184 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_23_185 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_24_186 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_24_187 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_24_188 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_24_189 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_25_190 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_25_191 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_25_192 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_25_193 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_26_194 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_26_195 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_26_196 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_26_197 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_27_198 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_27_199 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_27_200 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_27_201 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_28_202 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_28_203 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_28_204 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_28_205 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_29_206 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_29_207 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_29_208 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_29_209 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_2_100 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_2_101 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_2_98 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_2_99 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_30_210 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_30_211 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_30_212 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_30_213 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_31_214 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_31_215 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_31_216 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_31_217 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_32_218 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_32_219 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_32_220 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_32_221 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_33_222 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_33_223 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_33_224 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_33_225 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_34_226 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_34_227 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_34_228 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_34_229 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_35_230 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_35_231 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_35_232 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_35_233 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_36_234 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_36_235 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_36_236 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_36_237 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_37_238 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_37_239 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_37_240 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_37_241 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_38_242 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_38_243 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_38_244 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_38_245 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_39_246 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_39_247 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_39_248 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_39_249 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_3_102 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_3_103 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_3_104 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_3_105 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_40_250 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_40_251 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_40_252 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_40_253 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_41_254 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_41_255 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_41_256 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_41_257 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_42_258 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_42_259 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_42_260 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_42_261 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_42_262 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_42_263 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_42_264 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_42_265 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_4_106 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_4_107 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_4_108 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_4_109 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_5_110 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_5_111 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_5_112 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_5_113 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_6_114 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_6_115 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_6_116 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_6_117 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_7_118 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_7_119 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_7_120 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_7_121 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_8_122 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_8_123 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_8_124 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_8_125 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_9_126 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_9_127 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_9_128 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_9_129 ();
 sky130_fd_sc_hd__xor2_1 _214_ (.A(data_i[49]),
    .B(_193_),
    .X(data_o[43]));
 sky130_fd_sc_hd__nor2_1 _215_ (.A(_153_),
    .B(_176_),
    .Y(_194_));
 sky130_fd_sc_hd__xor2_1 _216_ (.A(data_i[50]),
    .B(_194_),
    .X(data_o[44]));
 sky130_fd_sc_hd__nor2_1 _217_ (.A(_157_),
    .B(_178_),
    .Y(_195_));
 sky130_fd_sc_hd__xor2_1 _218_ (.A(data_i[51]),
    .B(_195_),
    .X(data_o[45]));
 sky130_fd_sc_hd__nor2_1 _219_ (.A(_157_),
    .B(_172_),
    .Y(_196_));
 sky130_fd_sc_hd__xor2_1 _220_ (.A(data_i[52]),
    .B(_196_),
    .X(data_o[46]));
 sky130_fd_sc_hd__nor2_1 _221_ (.A(_157_),
    .B(_174_),
    .Y(_197_));
 sky130_fd_sc_hd__xor2_1 _222_ (.A(data_i[53]),
    .B(_197_),
    .X(data_o[47]));
 sky130_fd_sc_hd__nor2_1 _223_ (.A(_157_),
    .B(_176_),
    .Y(_198_));
 sky130_fd_sc_hd__xor2_1 _224_ (.A(data_i[54]),
    .B(_198_),
    .X(data_o[48]));
 sky130_fd_sc_hd__nor2_1 _225_ (.A(_162_),
    .B(_178_),
    .Y(_199_));
 sky130_fd_sc_hd__xor2_1 _226_ (.A(data_i[55]),
    .B(_199_),
    .X(data_o[49]));
 sky130_fd_sc_hd__nor2_1 _227_ (.A(_162_),
    .B(_172_),
    .Y(_200_));
 sky130_fd_sc_hd__xor2_1 _228_ (.A(data_i[56]),
    .B(_200_),
    .X(data_o[50]));
 sky130_fd_sc_hd__nor2_1 _229_ (.A(_162_),
    .B(_174_),
    .Y(_201_));
 sky130_fd_sc_hd__xor2_1 _230_ (.A(data_i[57]),
    .B(_201_),
    .X(data_o[51]));
 sky130_fd_sc_hd__nor2_1 _231_ (.A(_162_),
    .B(_176_),
    .Y(_202_));
 sky130_fd_sc_hd__xor2_1 _232_ (.A(data_i[58]),
    .B(_202_),
    .X(data_o[52]));
 sky130_fd_sc_hd__nor2_1 _233_ (.A(_167_),
    .B(_178_),
    .Y(_203_));
 sky130_fd_sc_hd__xor2_1 _234_ (.A(data_i[59]),
    .B(_203_),
    .X(data_o[53]));
 sky130_fd_sc_hd__nor2_1 _235_ (.A(_167_),
    .B(_172_),
    .Y(_204_));
 sky130_fd_sc_hd__xor2_1 _236_ (.A(data_i[60]),
    .B(_204_),
    .X(data_o[54]));
 sky130_fd_sc_hd__nor2_1 _237_ (.A(_167_),
    .B(_174_),
    .Y(_205_));
 sky130_fd_sc_hd__xor2_1 _238_ (.A(data_i[61]),
    .B(_205_),
    .X(data_o[55]));
 sky130_fd_sc_hd__nor2_1 _239_ (.A(_167_),
    .B(_176_),
    .Y(_206_));
 sky130_fd_sc_hd__xor2_1 _240_ (.A(data_i[62]),
    .B(_206_),
    .X(data_o[56]));
 sky130_fd_sc_hd__nand3b_1 _241_ (.A_N(_122_),
    .B(_125_),
    .C(_135_),
    .Y(_207_));
 sky130_fd_sc_hd__xnor2_1 _242_ (.A(data_i[64]),
    .B(_207_),
    .Y(data_o[57]));
 sky130_fd_sc_hd__nand3b_1 _243_ (.A_N(_122_),
    .B(_125_),
    .C(_140_),
    .Y(_208_));
 sky130_fd_sc_hd__xnor2_1 _244_ (.A(data_i[65]),
    .B(_208_),
    .Y(data_o[58]));
 sky130_fd_sc_hd__nand3b_1 _245_ (.A_N(_122_),
    .B(_125_),
    .C(_132_),
    .Y(_209_));
 sky130_fd_sc_hd__xnor2_1 _246_ (.A(data_i[66]),
    .B(_209_),
    .Y(data_o[59]));
 sky130_fd_sc_hd__nand4_1 _247_ (.A(_105_),
    .B(_121_),
    .C(_125_),
    .D(_137_),
    .Y(_210_));
 sky130_fd_sc_hd__xnor2_1 _248_ (.A(data_i[67]),
    .B(_210_),
    .Y(data_o[60]));
 sky130_fd_sc_hd__nand3_1 _249_ (.A(_125_),
    .B(_135_),
    .C(_137_),
    .Y(_211_));
 sky130_fd_sc_hd__xnor2_1 _250_ (.A(data_i[68]),
    .B(_211_),
    .Y(data_o[61]));
 sky130_fd_sc_hd__nand3_1 _251_ (.A(_125_),
    .B(_137_),
    .C(_140_),
    .Y(_212_));
 sky130_fd_sc_hd__xnor2_1 _252_ (.A(data_i[69]),
    .B(_212_),
    .Y(data_o[62]));
 sky130_fd_sc_hd__nand3_1 _253_ (.A(_125_),
    .B(_132_),
    .C(_137_),
    .Y(_213_));
 sky130_fd_sc_hd__xnor2_1 _254_ (.A(data_i[70]),
    .B(_213_),
    .Y(data_o[63]));
 sky130_fd_sc_hd__xor2_1 _255_ (.A(data_i[61]),
    .B(data_i[62]),
    .X(_000_));
 sky130_fd_sc_hd__xor2_1 _256_ (.A(data_i[59]),
    .B(data_i[60]),
    .X(_001_));
 sky130_fd_sc_hd__xnor2_1 _257_ (.A(_000_),
    .B(_001_),
    .Y(_002_));
 sky130_fd_sc_hd__xor2_1 _258_ (.A(data_i[45]),
    .B(data_i[46]),
    .X(_003_));
 sky130_fd_sc_hd__xor2_1 _259_ (.A(data_i[43]),
    .B(data_i[44]),
    .X(_004_));
 sky130_fd_sc_hd__xor2_1 _260_ (.A(_003_),
    .B(_004_),
    .X(_005_));
 sky130_fd_sc_hd__xnor2_1 _261_ (.A(_002_),
    .B(_005_),
    .Y(_006_));
 sky130_fd_sc_hd__xor2_1 _262_ (.A(data_i[56]),
    .B(data_i[58]),
    .X(_007_));
 sky130_fd_sc_hd__xor2_1 _263_ (.A(data_i[57]),
    .B(data_i[58]),
    .X(_008_));
 sky130_fd_sc_hd__xor2_1 _264_ (.A(data_i[55]),
    .B(data_i[56]),
    .X(_009_));
 sky130_fd_sc_hd__xor2_1 _265_ (.A(_008_),
    .B(_009_),
    .X(_010_));
 sky130_fd_sc_hd__xor2_1 _266_ (.A(data_i[41]),
    .B(data_i[42]),
    .X(_011_));
 sky130_fd_sc_hd__xnor2_1 _267_ (.A(data_i[39]),
    .B(data_i[40]),
    .Y(_012_));
 sky130_fd_sc_hd__xor2_1 _268_ (.A(_011_),
    .B(_012_),
    .X(_013_));
 sky130_fd_sc_hd__xor2_1 _269_ (.A(_010_),
    .B(_013_),
    .X(_014_));
 sky130_fd_sc_hd__xnor2_1 _270_ (.A(_006_),
    .B(_014_),
    .Y(_015_));
 sky130_fd_sc_hd__xor2_1 _271_ (.A(data_i[53]),
    .B(data_i[54]),
    .X(_016_));
 sky130_fd_sc_hd__xnor2_1 _272_ (.A(data_i[51]),
    .B(data_i[52]),
    .Y(_017_));
 sky130_fd_sc_hd__xor2_1 _273_ (.A(_016_),
    .B(_017_),
    .X(_018_));
 sky130_fd_sc_hd__xor2_1 _274_ (.A(data_i[49]),
    .B(data_i[50]),
    .X(_019_));
 sky130_fd_sc_hd__xor2_1 _275_ (.A(data_i[47]),
    .B(data_i[48]),
    .X(_020_));
 sky130_fd_sc_hd__xor2_1 _276_ (.A(_019_),
    .B(_020_),
    .X(_021_));
 sky130_fd_sc_hd__xnor2_1 _277_ (.A(_018_),
    .B(_021_),
    .Y(_022_));
 sky130_fd_sc_hd__xnor2_1 _278_ (.A(data_i[37]),
    .B(data_i[38]),
    .Y(_023_));
 sky130_fd_sc_hd__xor2_1 _279_ (.A(data_i[35]),
    .B(data_i[36]),
    .X(_024_));
 sky130_fd_sc_hd__xnor2_1 _280_ (.A(_023_),
    .B(_024_),
    .Y(_025_));
 sky130_fd_sc_hd__xor2_1 _281_ (.A(data_i[33]),
    .B(data_i[34]),
    .X(_026_));
 sky130_fd_sc_hd__xor2_1 _282_ (.A(data_i[31]),
    .B(data_i[32]),
    .X(_027_));
 sky130_fd_sc_hd__xor2_1 _283_ (.A(_026_),
    .B(_027_),
    .X(_028_));
 sky130_fd_sc_hd__xor2_1 _284_ (.A(_025_),
    .B(_028_),
    .X(_029_));
 sky130_fd_sc_hd__xnor2_1 _285_ (.A(_018_),
    .B(_025_),
    .Y(_030_));
 sky130_fd_sc_hd__xor2_1 _286_ (.A(_022_),
    .B(_029_),
    .X(_031_));
 sky130_fd_sc_hd__xnor2_1 _287_ (.A(_015_),
    .B(_031_),
    .Y(_032_));
 sky130_fd_sc_hd__clkinv_1 _288_ (.A(_032_),
    .Y(syndrome_o[5]));
 sky130_fd_sc_hd__xor2_1 _289_ (.A(_002_),
    .B(_010_),
    .X(_033_));
 sky130_fd_sc_hd__xnor2_1 _290_ (.A(data_i[17]),
    .B(data_i[18]),
    .Y(_034_));
 sky130_fd_sc_hd__xor2_1 _291_ (.A(data_i[15]),
    .B(data_i[16]),
    .X(_035_));
 sky130_fd_sc_hd__xor2_1 _292_ (.A(_034_),
    .B(_035_),
    .X(_036_));
 sky130_fd_sc_hd__xnor2_1 _293_ (.A(data_i[21]),
    .B(data_i[22]),
    .Y(_037_));
 sky130_fd_sc_hd__xor2_1 _294_ (.A(data_i[19]),
    .B(data_i[20]),
    .X(_038_));
 sky130_fd_sc_hd__xnor2_1 _295_ (.A(_037_),
    .B(_038_),
    .Y(_039_));
 sky130_fd_sc_hd__xor2_1 _296_ (.A(_036_),
    .B(_039_),
    .X(_040_));
 sky130_fd_sc_hd__xnor2_1 _297_ (.A(data_i[24]),
    .B(data_i[26]),
    .Y(_041_));
 sky130_fd_sc_hd__xor2_1 _298_ (.A(data_i[25]),
    .B(data_i[26]),
    .X(_042_));
 sky130_fd_sc_hd__xor2_1 _299_ (.A(data_i[23]),
    .B(data_i[24]),
    .X(_043_));
 sky130_fd_sc_hd__xor2_1 _300_ (.A(_042_),
    .B(_043_),
    .X(_044_));
 sky130_fd_sc_hd__xor2_1 _301_ (.A(data_i[29]),
    .B(data_i[30]),
    .X(_045_));
 sky130_fd_sc_hd__xnor2_1 _302_ (.A(data_i[27]),
    .B(data_i[28]),
    .Y(_046_));
 sky130_fd_sc_hd__xnor2_1 _303_ (.A(_045_),
    .B(_046_),
    .Y(_047_));
 sky130_fd_sc_hd__xnor2_1 _304_ (.A(_044_),
    .B(_047_),
    .Y(_048_));
 sky130_fd_sc_hd__xor2_1 _305_ (.A(_033_),
    .B(_048_),
    .X(_049_));
 sky130_fd_sc_hd__xnor2_1 _306_ (.A(_022_),
    .B(_040_),
    .Y(_050_));
 sky130_fd_sc_hd__xor2_1 _307_ (.A(_049_),
    .B(_050_),
    .X(syndrome_o[4]));
 sky130_fd_sc_hd__xnor2_1 _308_ (.A(data_i[13]),
    .B(data_i[14]),
    .Y(_051_));
 sky130_fd_sc_hd__xnor2_1 _309_ (.A(data_i[11]),
    .B(data_i[12]),
    .Y(_052_));
 sky130_fd_sc_hd__xnor2_1 _310_ (.A(_051_),
    .B(_052_),
    .Y(_053_));
 sky130_fd_sc_hd__xor2_1 _311_ (.A(data_i[9]),
    .B(data_i[10]),
    .X(_054_));
 sky130_fd_sc_hd__xor2_1 _312_ (.A(data_i[7]),
    .B(data_i[8]),
    .X(_055_));
 sky130_fd_sc_hd__xor2_1 _313_ (.A(_054_),
    .B(_055_),
    .X(_056_));
 sky130_fd_sc_hd__xor2_1 _314_ (.A(_053_),
    .B(_056_),
    .X(_057_));
 sky130_fd_sc_hd__xor2_1 _315_ (.A(_048_),
    .B(_057_),
    .X(_058_));
 sky130_fd_sc_hd__xnor2_1 _316_ (.A(_015_),
    .B(_058_),
    .Y(_059_));
 sky130_fd_sc_hd__inv_1 _317_ (.A(_059_),
    .Y(syndrome_o[3]));
 sky130_fd_sc_hd__xnor2_1 _318_ (.A(data_i[5]),
    .B(data_i[6]),
    .Y(_060_));
 sky130_fd_sc_hd__xor2_1 _319_ (.A(data_i[3]),
    .B(data_i[4]),
    .X(_061_));
 sky130_fd_sc_hd__xor2_1 _320_ (.A(_060_),
    .B(_061_),
    .X(_062_));
 sky130_fd_sc_hd__xor2_1 _321_ (.A(data_i[68]),
    .B(data_i[70]),
    .X(_063_));
 sky130_fd_sc_hd__xor2_1 _322_ (.A(data_i[67]),
    .B(data_i[69]),
    .X(_064_));
 sky130_fd_sc_hd__xor2_1 _323_ (.A(data_i[69]),
    .B(data_i[70]),
    .X(_065_));
 sky130_fd_sc_hd__xor2_1 _324_ (.A(_063_),
    .B(_064_),
    .X(_066_));
 sky130_fd_sc_hd__xor2_1 _325_ (.A(_039_),
    .B(_062_),
    .X(_067_));
 sky130_fd_sc_hd__xnor3_1 _326_ (.A(_047_),
    .B(_053_),
    .C(_067_),
    .X(_068_));
 sky130_fd_sc_hd__xor2_1 _327_ (.A(_066_),
    .B(_030_),
    .X(_069_));
 sky130_fd_sc_hd__xnor3_2 _328_ (.A(_006_),
    .B(_069_),
    .C(_068_),
    .X(syndrome_o[2]));
 sky130_fd_sc_hd__xnor2_1 _330_ (.A(data_i[65]),
    .B(data_i[66]),
    .Y(_071_));
 sky130_fd_sc_hd__xor2_1 _331_ (.A(data_i[63]),
    .B(data_i[64]),
    .X(_072_));
 sky130_fd_sc_hd__xor2_1 _332_ (.A(_071_),
    .B(_072_),
    .X(_073_));
 sky130_fd_sc_hd__xor2_1 _333_ (.A(_066_),
    .B(_073_),
    .X(_074_));
 sky130_fd_sc_hd__clkinv_1 _334_ (.A(_074_),
    .Y(syndrome_o[6]));
 sky130_fd_sc_hd__xor2_1 _335_ (.A(data_i[12]),
    .B(data_i[14]),
    .X(_075_));
 sky130_fd_sc_hd__xor2_1 _336_ (.A(_041_),
    .B(_075_),
    .X(_076_));
 sky130_fd_sc_hd__xor2_1 _337_ (.A(data_i[28]),
    .B(data_i[30]),
    .X(_077_));
 sky130_fd_sc_hd__xor2_1 _338_ (.A(data_i[8]),
    .B(data_i[10]),
    .X(_078_));
 sky130_fd_sc_hd__xor2_1 _339_ (.A(_077_),
    .B(_078_),
    .X(_079_));
 sky130_fd_sc_hd__xor2_1 _340_ (.A(_076_),
    .B(_079_),
    .X(_080_));
 sky130_fd_sc_hd__xor2_1 _341_ (.A(data_i[36]),
    .B(data_i[38]),
    .X(_081_));
 sky130_fd_sc_hd__xor2_1 _342_ (.A(data_i[48]),
    .B(data_i[50]),
    .X(_082_));
 sky130_fd_sc_hd__xor2_1 _343_ (.A(_081_),
    .B(_082_),
    .X(_083_));
 sky130_fd_sc_hd__xor2_1 _344_ (.A(data_i[32]),
    .B(data_i[34]),
    .X(_084_));
 sky130_fd_sc_hd__xor2_1 _345_ (.A(data_i[52]),
    .B(data_i[54]),
    .X(_085_));
 sky130_fd_sc_hd__xor2_1 _346_ (.A(_084_),
    .B(_085_),
    .X(_086_));
 sky130_fd_sc_hd__xor2_1 _347_ (.A(_083_),
    .B(_086_),
    .X(_087_));
 sky130_fd_sc_hd__xor2_1 _348_ (.A(_080_),
    .B(_087_),
    .X(_088_));
 sky130_fd_sc_hd__xor2_1 _349_ (.A(data_i[40]),
    .B(data_i[42]),
    .X(_089_));
 sky130_fd_sc_hd__xnor2_1 _350_ (.A(data_i[60]),
    .B(data_i[62]),
    .Y(_090_));
 sky130_fd_sc_hd__xor2_1 _351_ (.A(_089_),
    .B(_090_),
    .X(_091_));
 sky130_fd_sc_hd__xor2_1 _352_ (.A(data_i[44]),
    .B(data_i[46]),
    .X(_092_));
 sky130_fd_sc_hd__xor2_1 _353_ (.A(_007_),
    .B(_092_),
    .X(_093_));
 sky130_fd_sc_hd__xor2_1 _354_ (.A(data_i[16]),
    .B(data_i[18]),
    .X(_094_));
 sky130_fd_sc_hd__xor2_1 _355_ (.A(data_i[20]),
    .B(data_i[22]),
    .X(_095_));
 sky130_fd_sc_hd__xor2_1 _356_ (.A(_094_),
    .B(_095_),
    .X(_096_));
 sky130_fd_sc_hd__xor2_1 _357_ (.A(data_i[0]),
    .B(data_i[2]),
    .X(_097_));
 sky130_fd_sc_hd__xor2_1 _358_ (.A(_096_),
    .B(_097_),
    .X(_098_));
 sky130_fd_sc_hd__xor2_1 _359_ (.A(data_i[64]),
    .B(data_i[66]),
    .X(_099_));
 sky130_fd_sc_hd__xnor2_1 _360_ (.A(data_i[4]),
    .B(data_i[6]),
    .Y(_100_));
 sky130_fd_sc_hd__xor2_1 _361_ (.A(_063_),
    .B(_100_),
    .X(_101_));
 sky130_fd_sc_hd__xor2_1 _362_ (.A(_099_),
    .B(_101_),
    .X(_102_));
 sky130_fd_sc_hd__xor2_1 _363_ (.A(_098_),
    .B(_102_),
    .X(_103_));
 sky130_fd_sc_hd__xor2_1 _364_ (.A(_091_),
    .B(_093_),
    .X(_104_));
 sky130_fd_sc_hd__xor3_1 _365_ (.A(_088_),
    .B(_103_),
    .C(_104_),
    .X(_105_));
 sky130_fd_sc_hd__clkinv_1 _366_ (.A(_105_),
    .Y(syndrome_o[0]));
 sky130_fd_sc_hd__xor2_1 _367_ (.A(_042_),
    .B(_054_),
    .X(_106_));
 sky130_fd_sc_hd__xor2_1 _368_ (.A(_034_),
    .B(_037_),
    .X(_107_));
 sky130_fd_sc_hd__xor2_1 _369_ (.A(_106_),
    .B(_107_),
    .X(_108_));
 sky130_fd_sc_hd__xor2_1 _370_ (.A(_045_),
    .B(_051_),
    .X(_109_));
 sky130_fd_sc_hd__xor2_1 _371_ (.A(_008_),
    .B(_011_),
    .X(_110_));
 sky130_fd_sc_hd__xnor2_1 _372_ (.A(_019_),
    .B(_026_),
    .Y(_111_));
 sky130_fd_sc_hd__xnor2_1 _373_ (.A(_016_),
    .B(_023_),
    .Y(_112_));
 sky130_fd_sc_hd__xor2_1 _374_ (.A(_000_),
    .B(_003_),
    .X(_113_));
 sky130_fd_sc_hd__xor2_1 _375_ (.A(_112_),
    .B(_113_),
    .X(_114_));
 sky130_fd_sc_hd__xnor3_1 _376_ (.A(_110_),
    .B(_111_),
    .C(_114_),
    .X(_115_));
 sky130_fd_sc_hd__xor2_1 _377_ (.A(data_i[2]),
    .B(data_i[1]),
    .X(_116_));
 sky130_fd_sc_hd__xor2_1 _378_ (.A(_060_),
    .B(_116_),
    .X(_117_));
 sky130_fd_sc_hd__xor2_1 _379_ (.A(_109_),
    .B(_117_),
    .X(_118_));
 sky130_fd_sc_hd__xor2_1 _380_ (.A(_065_),
    .B(_071_),
    .X(_119_));
 sky130_fd_sc_hd__xor2_1 _381_ (.A(_108_),
    .B(_118_),
    .X(_120_));
 sky130_fd_sc_hd__xor3_1 _382_ (.A(_115_),
    .B(_119_),
    .C(_120_),
    .X(_121_));
 sky130_fd_sc_hd__clkinv_1 _383_ (.A(_121_),
    .Y(syndrome_o[1]));
 sky130_fd_sc_hd__or3_1 _384_ (.A(syndrome_o[4]),
    .B(syndrome_o[2]),
    .C(syndrome_o[3]),
    .X(_122_));
 sky130_fd_sc_hd__nand4_1 _385_ (.A(_032_),
    .B(_074_),
    .C(_105_),
    .D(_121_),
    .Y(_123_));
 sky130_fd_sc_hd__nor2_1 _386_ (.A(_122_),
    .B(_123_),
    .Y(_124_));
 sky130_fd_sc_hd__nor2_1 _387_ (.A(syndrome_o[5]),
    .B(_074_),
    .Y(_125_));
 sky130_fd_sc_hd__xor2_1 _388_ (.A(syndrome_o[5]),
    .B(syndrome_o[6]),
    .X(_126_));
 sky130_fd_sc_hd__xor2_1 _389_ (.A(data_i[1]),
    .B(_097_),
    .X(_127_));
 sky130_fd_sc_hd__xor2_1 _390_ (.A(_062_),
    .B(_127_),
    .X(_128_));
 sky130_fd_sc_hd__xor2_1 _391_ (.A(_040_),
    .B(_128_),
    .X(_129_));
 sky130_fd_sc_hd__xnor3_1 _392_ (.A(data_i[71]),
    .B(_058_),
    .C(_129_),
    .X(_130_));
 sky130_fd_sc_hd__xor2_1 _393_ (.A(_126_),
    .B(_130_),
    .X(_131_));
 sky130_fd_sc_hd__nor2_1 _394_ (.A(_124_),
    .B(_131_),
    .Y(single_error_o));
 sky130_fd_sc_hd__nor3_1 _395_ (.A(_122_),
    .B(_123_),
    .C(_131_),
    .Y(parity_error_o));
 sky130_fd_sc_hd__lpflow_isobufsrc_1 _396_ (.A(_131_),
    .SLEEP(_124_),
    .X(double_error_o));
 sky130_fd_sc_hd__nor2_1 _397_ (.A(_105_),
    .B(_121_),
    .Y(_132_));
 sky130_fd_sc_hd__nand4_1 _398_ (.A(_032_),
    .B(_074_),
    .C(syndrome_o[0]),
    .D(syndrome_o[1]),
    .Y(_133_));
 sky130_fd_sc_hd__nor2_1 _399_ (.A(_122_),
    .B(_133_),
    .Y(_134_));
 sky130_fd_sc_hd__xor2_1 _400_ (.A(data_i[2]),
    .B(_134_),
    .X(data_o[0]));
 sky130_fd_sc_hd__nor2_1 _401_ (.A(_105_),
    .B(syndrome_o[1]),
    .Y(_135_));
 sky130_fd_sc_hd__nand4_1 _402_ (.A(_032_),
    .B(_074_),
    .C(syndrome_o[0]),
    .D(_121_),
    .Y(_136_));
 sky130_fd_sc_hd__nor3b_1 _403_ (.A(syndrome_o[4]),
    .B(syndrome_o[3]),
    .C_N(syndrome_o[2]),
    .Y(_137_));
 sky130_fd_sc_hd__or3b_1 _404_ (.A(syndrome_o[4]),
    .B(syndrome_o[3]),
    .C_N(syndrome_o[2]),
    .X(_138_));
 sky130_fd_sc_hd__nor2_1 _405_ (.A(_136_),
    .B(_138_),
    .Y(_139_));
 sky130_fd_sc_hd__xor2_1 _406_ (.A(data_i[4]),
    .B(_139_),
    .X(data_o[1]));
 sky130_fd_sc_hd__nor2_1 _407_ (.A(syndrome_o[0]),
    .B(_121_),
    .Y(_140_));
 sky130_fd_sc_hd__nand4_1 _408_ (.A(_032_),
    .B(_074_),
    .C(_105_),
    .D(syndrome_o[1]),
    .Y(_141_));
 sky130_fd_sc_hd__nor2_1 _409_ (.A(_138_),
    .B(_141_),
    .Y(_142_));
 sky130_fd_sc_hd__xor2_1 _410_ (.A(data_i[5]),
    .B(_142_),
    .X(data_o[2]));
 sky130_fd_sc_hd__nor2_1 _411_ (.A(_133_),
    .B(_138_),
    .Y(_143_));
 sky130_fd_sc_hd__xor2_1 _412_ (.A(data_i[6]),
    .B(_143_),
    .X(data_o[3]));
 sky130_fd_sc_hd__or3_1 _413_ (.A(syndrome_o[4]),
    .B(_059_),
    .C(syndrome_o[2]),
    .X(_144_));
 sky130_fd_sc_hd__nor2_1 _414_ (.A(_136_),
    .B(_144_),
    .Y(_145_));
 sky130_fd_sc_hd__xor2_1 _415_ (.A(data_i[8]),
    .B(_145_),
    .X(data_o[4]));
 sky130_fd_sc_hd__nor2_1 _416_ (.A(_141_),
    .B(_144_),
    .Y(_146_));
 sky130_fd_sc_hd__xor2_1 _417_ (.A(data_i[9]),
    .B(_146_),
    .X(data_o[5]));
 sky130_fd_sc_hd__nor2_1 _418_ (.A(_133_),
    .B(_144_),
    .Y(_147_));
 sky130_fd_sc_hd__xor2_1 _419_ (.A(data_i[10]),
    .B(_147_),
    .X(data_o[6]));
 sky130_fd_sc_hd__or3b_1 _420_ (.A(syndrome_o[4]),
    .B(_059_),
    .C_N(syndrome_o[2]),
    .X(_148_));
 sky130_fd_sc_hd__nor2_1 _421_ (.A(_123_),
    .B(_148_),
    .Y(_149_));
 sky130_fd_sc_hd__xor2_1 _422_ (.A(data_i[11]),
    .B(_149_),
    .X(data_o[7]));
 sky130_fd_sc_hd__nor2_1 _423_ (.A(_136_),
    .B(_148_),
    .Y(_150_));
 sky130_fd_sc_hd__xor2_1 _424_ (.A(data_i[12]),
    .B(_150_),
    .X(data_o[8]));
 sky130_fd_sc_hd__nor2_1 _425_ (.A(_141_),
    .B(_148_),
    .Y(_151_));
 sky130_fd_sc_hd__xor2_1 _426_ (.A(data_i[13]),
    .B(_151_),
    .X(data_o[9]));
 sky130_fd_sc_hd__nor2_1 _427_ (.A(_133_),
    .B(_148_),
    .Y(_152_));
 sky130_fd_sc_hd__xor2_1 _428_ (.A(data_i[14]),
    .B(_152_),
    .X(data_o[10]));
 sky130_fd_sc_hd__nand3b_1 _429_ (.A_N(syndrome_o[2]),
    .B(syndrome_o[4]),
    .C(_059_),
    .Y(_153_));
 sky130_fd_sc_hd__nor2_1 _430_ (.A(_136_),
    .B(_153_),
    .Y(_154_));
 sky130_fd_sc_hd__xor2_1 _431_ (.A(data_i[16]),
    .B(_154_),
    .X(data_o[11]));
 sky130_fd_sc_hd__nor2_1 _432_ (.A(_141_),
    .B(_153_),
    .Y(_155_));
 sky130_fd_sc_hd__xor2_1 _433_ (.A(data_i[17]),
    .B(_155_),
    .X(data_o[12]));
 sky130_fd_sc_hd__nor2_1 _434_ (.A(_133_),
    .B(_153_),
    .Y(_156_));
 sky130_fd_sc_hd__xor2_1 _435_ (.A(data_i[18]),
    .B(_156_),
    .X(data_o[13]));
 sky130_fd_sc_hd__nand3_1 _436_ (.A(syndrome_o[4]),
    .B(_059_),
    .C(syndrome_o[2]),
    .Y(_157_));
 sky130_fd_sc_hd__nor2_1 _437_ (.A(_123_),
    .B(_157_),
    .Y(_158_));
 sky130_fd_sc_hd__xor2_1 _438_ (.A(data_i[19]),
    .B(_158_),
    .X(data_o[14]));
 sky130_fd_sc_hd__nor2_1 _439_ (.A(_136_),
    .B(_157_),
    .Y(_159_));
 sky130_fd_sc_hd__xor2_1 _440_ (.A(data_i[20]),
    .B(_159_),
    .X(data_o[15]));
 sky130_fd_sc_hd__nor2_1 _441_ (.A(_141_),
    .B(_157_),
    .Y(_160_));
 sky130_fd_sc_hd__xor2_1 _442_ (.A(data_i[21]),
    .B(_160_),
    .X(data_o[16]));
 sky130_fd_sc_hd__nor2_1 _443_ (.A(_133_),
    .B(_157_),
    .Y(_161_));
 sky130_fd_sc_hd__xor2_1 _444_ (.A(data_i[22]),
    .B(_161_),
    .X(data_o[17]));
 sky130_fd_sc_hd__nand3b_1 _445_ (.A_N(syndrome_o[2]),
    .B(syndrome_o[4]),
    .C(syndrome_o[3]),
    .Y(_162_));
 sky130_fd_sc_hd__nor2_1 _446_ (.A(_123_),
    .B(_162_),
    .Y(_163_));
 sky130_fd_sc_hd__xor2_1 _447_ (.A(data_i[23]),
    .B(_163_),
    .X(data_o[18]));
 sky130_fd_sc_hd__nor2_1 _448_ (.A(_136_),
    .B(_162_),
    .Y(_164_));
 sky130_fd_sc_hd__xor2_1 _449_ (.A(data_i[24]),
    .B(_164_),
    .X(data_o[19]));
 sky130_fd_sc_hd__nor2_1 _450_ (.A(_141_),
    .B(_162_),
    .Y(_165_));
 sky130_fd_sc_hd__xor2_1 _451_ (.A(data_i[25]),
    .B(_165_),
    .X(data_o[20]));
 sky130_fd_sc_hd__nor2_1 _452_ (.A(_133_),
    .B(_162_),
    .Y(_166_));
 sky130_fd_sc_hd__xor2_1 _453_ (.A(data_i[26]),
    .B(_166_),
    .X(data_o[21]));
 sky130_fd_sc_hd__nand3_1 _454_ (.A(syndrome_o[4]),
    .B(syndrome_o[3]),
    .C(syndrome_o[2]),
    .Y(_167_));
 sky130_fd_sc_hd__nor2_1 _455_ (.A(_123_),
    .B(_167_),
    .Y(_168_));
 sky130_fd_sc_hd__xor2_1 _456_ (.A(data_i[27]),
    .B(_168_),
    .X(data_o[22]));
 sky130_fd_sc_hd__nor2_1 _457_ (.A(_136_),
    .B(_167_),
    .Y(_169_));
 sky130_fd_sc_hd__xor2_1 _458_ (.A(data_i[28]),
    .B(_169_),
    .X(data_o[23]));
 sky130_fd_sc_hd__nor2_1 _459_ (.A(_141_),
    .B(_167_),
    .Y(_170_));
 sky130_fd_sc_hd__xor2_1 _460_ (.A(data_i[29]),
    .B(_170_),
    .X(data_o[24]));
 sky130_fd_sc_hd__nor2_1 _461_ (.A(_133_),
    .B(_167_),
    .Y(_171_));
 sky130_fd_sc_hd__xor2_1 _462_ (.A(data_i[30]),
    .B(_171_),
    .X(data_o[25]));
 sky130_fd_sc_hd__nand4_1 _463_ (.A(syndrome_o[5]),
    .B(_074_),
    .C(syndrome_o[0]),
    .D(_121_),
    .Y(_172_));
 sky130_fd_sc_hd__nor2_1 _464_ (.A(_122_),
    .B(_172_),
    .Y(_173_));
 sky130_fd_sc_hd__xor2_1 _465_ (.A(data_i[32]),
    .B(_173_),
    .X(data_o[26]));
 sky130_fd_sc_hd__nand4_1 _466_ (.A(syndrome_o[5]),
    .B(_074_),
    .C(_105_),
    .D(syndrome_o[1]),
    .Y(_174_));
 sky130_fd_sc_hd__nor2_1 _467_ (.A(_122_),
    .B(_174_),
    .Y(_175_));
 sky130_fd_sc_hd__xor2_1 _468_ (.A(data_i[33]),
    .B(_175_),
    .X(data_o[27]));
 sky130_fd_sc_hd__nand4_1 _469_ (.A(syndrome_o[5]),
    .B(_074_),
    .C(syndrome_o[0]),
    .D(syndrome_o[1]),
    .Y(_176_));
 sky130_fd_sc_hd__nor2_1 _470_ (.A(_122_),
    .B(_176_),
    .Y(_177_));
 sky130_fd_sc_hd__xor2_1 _471_ (.A(data_i[34]),
    .B(_177_),
    .X(data_o[28]));
 sky130_fd_sc_hd__nand4_1 _472_ (.A(syndrome_o[5]),
    .B(_074_),
    .C(_105_),
    .D(_121_),
    .Y(_178_));
 sky130_fd_sc_hd__nor2_1 _473_ (.A(_138_),
    .B(_178_),
    .Y(_179_));
 sky130_fd_sc_hd__xor2_1 _474_ (.A(data_i[35]),
    .B(_179_),
    .X(data_o[29]));
 sky130_fd_sc_hd__nor2_1 _475_ (.A(_138_),
    .B(_172_),
    .Y(_180_));
 sky130_fd_sc_hd__xor2_1 _476_ (.A(data_i[36]),
    .B(_180_),
    .X(data_o[30]));
 sky130_fd_sc_hd__nor2_1 _477_ (.A(_138_),
    .B(_174_),
    .Y(_181_));
 sky130_fd_sc_hd__xor2_1 _478_ (.A(data_i[37]),
    .B(_181_),
    .X(data_o[31]));
 sky130_fd_sc_hd__nor2_1 _479_ (.A(_138_),
    .B(_176_),
    .Y(_182_));
 sky130_fd_sc_hd__xor2_1 _480_ (.A(data_i[38]),
    .B(_182_),
    .X(data_o[32]));
 sky130_fd_sc_hd__nor2_1 _481_ (.A(_144_),
    .B(_178_),
    .Y(_183_));
 sky130_fd_sc_hd__xor2_1 _482_ (.A(data_i[39]),
    .B(_183_),
    .X(data_o[33]));
 sky130_fd_sc_hd__nor2_1 _483_ (.A(_144_),
    .B(_172_),
    .Y(_184_));
 sky130_fd_sc_hd__xor2_1 _484_ (.A(data_i[40]),
    .B(_184_),
    .X(data_o[34]));
 sky130_fd_sc_hd__nor2_1 _485_ (.A(_144_),
    .B(_174_),
    .Y(_185_));
 sky130_fd_sc_hd__xor2_1 _486_ (.A(data_i[41]),
    .B(_185_),
    .X(data_o[35]));
 sky130_fd_sc_hd__nor2_1 _487_ (.A(_144_),
    .B(_176_),
    .Y(_186_));
 sky130_fd_sc_hd__xor2_1 _488_ (.A(data_i[42]),
    .B(_186_),
    .X(data_o[36]));
 sky130_fd_sc_hd__nor2_1 _489_ (.A(_148_),
    .B(_178_),
    .Y(_187_));
 sky130_fd_sc_hd__xor2_1 _490_ (.A(data_i[43]),
    .B(_187_),
    .X(data_o[37]));
 sky130_fd_sc_hd__nor2_1 _491_ (.A(_148_),
    .B(_172_),
    .Y(_188_));
 sky130_fd_sc_hd__xor2_1 _492_ (.A(data_i[44]),
    .B(_188_),
    .X(data_o[38]));
 sky130_fd_sc_hd__nor2_1 _493_ (.A(_148_),
    .B(_174_),
    .Y(_189_));
 sky130_fd_sc_hd__xor2_1 _494_ (.A(data_i[45]),
    .B(_189_),
    .X(data_o[39]));
 sky130_fd_sc_hd__nor2_1 _495_ (.A(_148_),
    .B(_176_),
    .Y(_190_));
 sky130_fd_sc_hd__xor2_1 _496_ (.A(data_i[46]),
    .B(_190_),
    .X(data_o[40]));
 sky130_fd_sc_hd__nor2_1 _497_ (.A(_153_),
    .B(_178_),
    .Y(_191_));
 sky130_fd_sc_hd__xor2_1 _498_ (.A(data_i[47]),
    .B(_191_),
    .X(data_o[41]));
 sky130_fd_sc_hd__nor2_1 _499_ (.A(_153_),
    .B(_172_),
    .Y(_192_));
 sky130_fd_sc_hd__xor2_1 _500_ (.A(data_i[48]),
    .B(_192_),
    .X(data_o[42]));
 sky130_fd_sc_hd__nor2_1 _501_ (.A(_153_),
    .B(_174_),
    .Y(_193_));
endmodule
